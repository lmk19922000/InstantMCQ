# FlipClock.js

Website and documentation at http://flipclockjs.com/

Copyright (c) 2013 Objective HTML, LCC shared under MIT LICENSE
